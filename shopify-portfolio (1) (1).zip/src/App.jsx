
import React, { useState, useEffect } from "react";

export default function App() {
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (toast) {
      const id = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(id);
    }
  }, [toast]);

  const fallbackCopy = () => {
    try {
      const textarea = document.createElement('textarea');
      textarea.value = window.location.href;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'absolute';
      textarea.style.left = '-9999px';
      document.body.appendChild(textarea);
      textarea.select();

      const successful = document.execCommand('copy');
      document.body.removeChild(textarea);

      if (successful) {
        setToast('Link copied — send this page to clients');
      } else {
        setToast('Unable to copy automatically. Please copy the URL from your browser address bar.');
      }
    } catch (err) {
      console.error('Fallback copy failed', err);
      setToast('Clipboard not available — please copy the URL manually.');
    }
  };

  const handleCopy = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      navigator.clipboard
        .writeText(window.location.href)
        .then(() => setToast('Link copied — send this page to clients'))
        .catch((err) => {
          console.error('Clipboard write failed', err);
          fallbackCopy();
        });
    } else {
      fallbackCopy();
    }
  };

  return (
    <div style={{minHeight: '100vh', background: '#f8fafc', color: '#0f172a', fontFamily: 'Inter, system-ui, -apple-system, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial'}}>
      {toast && (
        <div style={{position:'fixed', top:16, right:16, background:'#16a34a', color:'#fff', padding:'10px 14px', borderRadius:8, boxShadow:'0 6px 18px rgba(15,23,42,0.12)', zIndex:50}}>
          {toast}
        </div>
      )}

      <header style={{background:'#fff', boxShadow:'0 1px 0 rgba(0,0,0,0.04)'}}>
        <div style={{maxWidth:960, margin:'0 auto', padding:'20px', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
          <div style={{display:'flex', alignItems:'center', gap:12}}>
            <div style={{width:44, height:44, borderRadius:8, background:'#059669', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700}}>SE</div>
            <div>
              <h1 style={{margin:0, fontSize:18}}>Shopify Expert Portfolio</h1>
              <p style={{margin:0, color:'#6b7280', fontSize:13}}>Shopify Partner Expert — store setup, payments, optimization</p>
            </div>
          </div>
          <nav style={{display:'flex', gap:12, fontSize:14}}>
            <a href=\"#services\">Services</a>
            <a href=\"#portfolio\">Portfolio</a>
            <a href=\"#about\">About</a>
          </nav>
        </div>
      </header>

      <main style={{maxWidth:960, margin:'0 auto', padding:'40px 20px'}}>
        <section style={{display:'grid', gridTemplateColumns:'1fr', gap:24, alignItems:'center'}}>
          <div>
            <h2 style={{fontSize:28, margin:0}}>Make your Shopify store confident and conversion-ready</h2>
            <p style={{marginTop:12, color:'#6b7280'}}>I help new and growing Shopify stores improve credibility, activate payments, pass KYC verification, and scale revenue with data-driven strategies.</p>

            <ul style={{marginTop:18, paddingLeft:20, color:'#111827'}}>
              <li style={{marginBottom:8}}><strong>Free store review</strong> — quick audit to find conversion blockers</li>
              <li style={{marginBottom:8}}><strong>Shopify Payments & KYC</strong> — activation and verification support</li>
              <li style={{marginBottom:8}}><strong>Conversion optimization</strong> — design, UX, speed and trust signals</li>
            </ul>

            <div style={{marginTop:20, display:'flex', gap:12}}>
              <button onClick={handleCopy} style={{background:'#059669', color:'#fff', border:'none', padding:'10px 16px', borderRadius:8, cursor:'pointer'}}>Copy portfolio link</button>
              <a href=\"#portfolio\" style={{display:'inline-block', border:'1px solid #059669', color:'#059669', padding:'10px 16px', borderRadius:8}}>View portfolio</a>
            </div>
          </div>

          <div style={{background:'#fff', borderRadius:8, padding:18, boxShadow:'0 6px 18px rgba(15,23,42,0.06)'}}>
            <h3 style={{margin:0, fontSize:18}}>What I review</h3>
            <ul style={{marginTop:12, color:'#374151'}}>
              <li>Homepage & trust signals</li>
              <li>Product pages & descriptions</li>
              <li>Checkout, payments & KYC readiness</li>
              <li>Email flows and recovery strategies</li>
              <li>Ads and retargeting setup</li>
            </ul>
            <div style={{marginTop:12, color:'#6b7280', fontSize:13}}>No upfront fees shown — we'll discuss the best approach after the review.</div>
          </div>
        </section>

        <section id=\"about\" style={{marginTop:36, background:'#fff', borderRadius:8, padding:18, boxShadow:'0 6px 18px rgba(15,23,42,0.06)'}}>
          <h3 style={{margin:0, fontSize:18}}>About</h3>
          <p style={{marginTop:12, color:'#374151'}}>Experienced Shopify consultant with over 10 years working in Shopify dropshipping, store optimization, and payments activation. I help store owners improve conversion rates, pass payment KYC checks, and scale reliable paid channels.</p>
        </section>

        <section id=\"services\" style={{marginTop:36}}>
          <h3 style={{fontSize:18}}>Services</h3>
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:16, marginTop:12}}>
            <div style={{background:'#fff', borderRadius:8, padding:14, boxShadow:'0 6px 18px rgba(15,23,42,0.04)'}}>
              <h4 style={{margin:0}}>Store Optimization</h4>
              <p style={{marginTop:8, color:'#6b7280'}}>Design audit, speed improvements, mobile UX, and trust elements to increase conversion.</p>
            </div>
            <div style={{background:'#fff', borderRadius:8, padding:14, boxShadow:'0 6px 18px rgba(15,23,42,0.04)'}}>
              <h4 style={{margin:0}}>Payments & KYC</h4>
              <p style={{marginTop:8, color:'#6b7280'}}>Guidance through Shopify Payments activation, documentation, and verification best practices.</p>
            </div>
            <div style={{background:'#fff', borderRadius:8, padding:14, boxShadow:'0 6px 18px rgba(15,23,42,0.04)'}}>
              <h4 style={{margin:0}}>Email & Retention</h4>
              <p style={{marginTop:8, color:'#6b7280'}}>Welcome flows, abandoned cart sequences, and post-purchase journeys to raise lifetime value.</p>
            </div>
            <div style={{background:'#fff', borderRadius:8, padding:14, boxShadow:'0 6px 18px rgba(15,23,42,0.04)'}}>
              <h4 style={{margin:0}}>Ads & Growth</h4>
              <p style={{marginTop:8, color:'#6b7280'}}>Facebook, Instagram, and TikTok campaigns with retargeting for efficient scaling.</p>
            </div>
          </div>
        </section>

        <section id=\"portfolio\" style={{marginTop:36}}>
          <h3 style={{fontSize:18}}>Portfolio — Past Work</h3>
          <p style={{marginTop:8, color:'#6b7280'}}>Examples of Shopify stores I've improved. Click to view:</p>

          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:16, marginTop:12}}>
            {[
              { title: 'supply.co', url: 'http://www.supply.co', note: 'Product page & checkout improvements' },
              { title: 'thebasiqlabel.com.au', url: 'http://www.thebasiqlabel.com.au', note: 'SEO & conversion improvements' },
              { title: 'cantaloupe-studio.com', url: 'http://www.cantaloupe-studio.com', note: 'Branding & UGC-driven ads' },
              { title: 'makemylemonade.com', url: 'http://www.makemylemonade.com', note: 'Paid ads & email automation' },
              { title: 'feasby-bleeks-home', url: 'http://www.feasby-bleeks-home.myshopify.com', note: 'Store optimization' }
            ].map((p) => (
              <a key={p.url} href={p.url} target="_blank" rel="noopener noreferrer" style={{display:'block', background:'#fff', borderRadius:8, padding:14, boxShadow:'0 6px 18px rgba(15,23,42,0.04)'}}>
                <div style={{height:140, background:'#f3f4f6', borderRadius:6, display:'flex', alignItems:'center', justifyContent:'center', color:'#9ca3af'}}>Thumbnail</div>
                <div style={{marginTop:12}}>
                  <div style={{fontWeight:700}}>{p.title}</div>
                  <div style={{color:'#6b7280', fontSize:13}}>{p.note}</div>
                </div>
              </a>
            ))}
          </div>
        </section>

        <footer style={{marginTop:40, textAlign:'center', color:'#6b7280'}}>
          <div style={{marginBottom:8}}>Powered by Shopify-style design • Digitally endorsed by a Shopify Partner Expert</div>
          <div>© {new Date().getFullYear()} — All rights reserved</div>
        </footer>
      </main>
    </div>
  );
}
